import { Person } from "./person.js";

export class Hero extends Person{
    title;
    fistname;
    lastname;
    _mission = "save the world";
    static power = 5;
    constructor(htitle, hfname, hlname, hcity){
        super(hcity);
        this.title = htitle;
        this.fistname = hfname;
        this.lastname = hlname;
    }
    fullname(){
        return this.fistname+" "+this.lastname;
    }
    get mission(){
        return this._mission;
    }
    set mission(nmission){
        this._mission = nmission;
    }
};