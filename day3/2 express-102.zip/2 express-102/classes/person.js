export class Person{
    constructor(hcity){
        this.city = hcity;
    }
}