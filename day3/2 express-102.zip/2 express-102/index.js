let express = require("express");
let app = express();

app.use(express.static(__dirname));

app.get("/", function(req, res){
    res.sendFile(__dirname+"/step23-using-modules.html");
});

app.listen(3030, "localhost", function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now live on localhost : 3030");
    }
})