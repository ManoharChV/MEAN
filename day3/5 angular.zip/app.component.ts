import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1> {{ title }} </h1>
  <h1 innerHTML="{{ title }}"></h1>
  <h1 [innerHTML]="title"></h1>
  <h1 [innerText]="title"> {{ title }} </h1>
  <h1 bind-textContent="title"></h1>
  `
})
export class AppComponent {
  title = 'Welcome to your life';
}
