let express = require("express");
let app = express();
let data = require("./data/data.json");

app.get("/data", function(req, res){
    // res.sendFile(__dirname+"/data/data.json");
    res.json(data);
})

app.listen(2525, "localhost", function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now live on localhost : 2525");
    }
})