function AddPower( config:any ){
    return function( targetClass : any ){
        return class{
            title = new targetClass().title;
            power = config.pow
        }
    }
}
@AddPower({
    pow : 7
})
class Hero{
    title = "Batman"
}
let hero = new Hero();
console.log(hero.title, hero.power);