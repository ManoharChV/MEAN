let appname:any = "asdf";
    appname = 555;

let heroes:Array<string> = ['batman','superman'];
let message:( number | string | boolean ) = "Welcome to your life";
alert(saymessage('hello','there',null));

interface IHero{
    title:string;
    fullname():string;
}
class Hero implements IHero{
    title:string = "Spiderman";
    private mission:string = "To Save New York";
    fullname():string{
        return "Peter Parker"
    }
    saymission(){
        return this.mission;
    }
}
let saymessage = function(arg1:any, arg2:any, arg3?:any):void{
    console.log(arg1, arg2);
};

/*
string
number
boolean
Array
Object
*/