"use strict";
var appname = "asdf";
appname = 555;
var saymessage = function (arg1, arg2, arg3) {
    console.log(arg1, arg2);
};
var heroes = ['batman', 'superman'];
var message = "Welcome to your life";
alert(saymessage('hello', 'there', null));
var Hero = /** @class */ (function () {
    function Hero() {
        this.title = "Spiderman";
        this.mission = "To Save New York";
    }
    Hero.prototype.fullname = function () {
        return "Peter Parker";
    };
    Hero.prototype.saymission = function () {
        return this.mission;
    };
    return Hero;
}());
/*
string
number
boolean
Array
Object
*/ 
